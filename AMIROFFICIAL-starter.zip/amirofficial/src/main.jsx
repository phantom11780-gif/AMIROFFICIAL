import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { motion } from 'framer-motion';
import { ArrowUpLeft, Instagram, Menu, X, Globe2, Radio, Send } from 'lucide-react';
import './style.css';

const copy = {
  fa: {
    nav: ['خانه', 'درباره من', 'رسانه', 'ارتباط'],
    eyebrow: 'رسانه شخصی • سیاست • تحلیل',
    headline: 'فراتر از تیترها،\\nبه دنبال حقیقت.',
    intro: 'اینجا فضایی برای دنبال‌کردن خبرها، بررسی رویدادهای سیاسی و بیان دیدگاه‌های مستقل است.',
    explore: 'مشاهده مطالب',
    about: 'درباره AMIROFFICIAL',
    aboutText: 'AMIROFFICIAL یک رسانه شخصی برای گفت‌وگو، تحلیل و نگاه انتقادی به اتفاقات روز است. هدف، پرسیدن سؤال‌های بهتر و دیدن موضوعات از زاویه‌های گوناگون است.',
    latest: 'از نگاه رسانه',
    latestSub: 'یادداشت‌ها، تحلیل‌ها و موضوعات روز',
    cards: [
      ['خبر و رویداد', 'مرور اتفاقات مهم و روایت‌های گوناگون از رویدادهای روز.'],
      ['تحلیل سیاسی', 'نگاهی عمیق‌تر به روندها، تصمیم‌ها و پیامدهای سیاسی.'],
      ['دیدگاه شخصی', 'یادداشت‌ها و نظرات مستقل درباره موضوعات مورد بحث.']
    ],
    note: 'این بخش نمونه اولیه است؛ مطالب واقعی را پیش از انتشار جایگزین کنید.',
    manifesto: 'آگاهی با پرسش آغاز می‌شود.',
    contact: 'در ارتباط باشیم',
    contactText: 'برای همکاری، گفت‌وگو یا دنبال‌کردن مطالب جدید از شبکه‌های اجتماعی استفاده کنید.',
    footer: 'تمام حقوق برای AMIROFFICIAL محفوظ است.'
  },
  en: {
    nav: ['Home', 'About', 'Media', 'Contact'],
    eyebrow: 'PERSONAL MEDIA • POLITICS • ANALYSIS',
    headline: 'Beyond the headlines,\\nin search of truth.',
    intro: 'A space to follow the news, examine political events, and share independent perspectives.',
    explore: 'Explore stories',
    about: 'About AMIROFFICIAL',
    aboutText: 'AMIROFFICIAL is a personal media platform for conversation, analysis, and a critical look at current events. The goal is to ask better questions and explore different perspectives.',
    latest: 'The media desk',
    latestSub: 'Notes, analysis, and current topics',
    cards: [
      ['News & Events', 'A look at important developments and different accounts of current events.'],
      ['Political Analysis', 'A deeper look at political trends, decisions, and consequences.'],
      ['Personal Views', 'Independent notes and opinions on topics being discussed.']
    ],
    note: 'This is a starter preview. Replace sample content before publishing.',
    manifesto: 'Awareness begins with a question.',
    contact: 'Stay connected',
    contactText: 'For collaboration, conversation, or updates, connect through social media.',
    footer: 'All rights reserved to AMIROFFICIAL.'
  }
};

function App() {
  const [lang, setLang] = useState('fa');
  const [menu, setMenu] = useState(false);
  const t = copy[lang];
  const rtl = lang === 'fa';
  return (
    <main dir={rtl ? 'rtl' : 'ltr'}>
      <header className="topbar">
        <a className="brand" href="#home">AMIR<span>OFFICIAL</span><i>.</i></a>
        <nav className={menu ? 'nav open' : 'nav'}>
          {t.nav.map((item, i) => <a key={item} href={['#home','#about','#media','#contact'][i]} onClick={() => setMenu(false)}>{item}</a>)}
        </nav>
        <div className="tools">
          <button className="lang" onClick={() => setLang(rtl ? 'en' : 'fa')}><Globe2 size={16}/>{rtl ? 'EN' : 'FA'}</button>
          <button className="menuBtn" onClick={() => setMenu(!menu)} aria-label="Toggle menu">{menu ? <X/> : <Menu/>}</button>
        </div>
      </header>

      <section className="hero" id="home">
        <div className="hero-grid"></div>
        <div className="hero-copy">
          <motion.div initial={{opacity:0,y:18}} animate={{opacity:1,y:0}} transition={{duration:.7}} className="eyebrow"><span></span>{t.eyebrow}</motion.div>
          <motion.h1 initial={{opacity:0,y:24}} animate={{opacity:1,y:0}} transition={{delay:.12,duration:.8}}>{t.headline.split('\\n').map((line,i)=><React.Fragment key={i}>{line}{i===0 && <br/>}</React.Fragment>)}</motion.h1>
          <p>{t.intro}</p>
          <a className="primary" href="#media">{t.explore}<ArrowUpLeft size={18}/></a>
        </div>
        <motion.div className="orb-wrap" initial={{opacity:0,scale:.8}} animate={{opacity:1,scale:1}} transition={{duration:1}}>
          <div className="orb"><div className="orb-core"></div><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="orb-label">A / O</div></div>
          <div className="side-caption">INDEPENDENT PERSPECTIVE — 01</div>
        </motion.div>
        <div className="hero-bottom"><span>01 / 04</span><span>SCROLL TO EXPLORE ↓</span></div>
      </section>

      <section className="about section" id="about">
        <div className="section-kicker">01 — {rtl ? 'معرفی' : 'INTRODUCTION'}</div>
        <div className="about-layout">
          <h2>{t.about}</h2>
          <p>{t.aboutText}</p>
        </div>
      </section>

      <section className="media section" id="media">
        <div className="section-kicker">02 — {rtl ? 'مطالب' : 'PUBLICATIONS'}</div>
        <div className="section-heading"><div><h2>{t.latest}</h2><p>{t.latestSub}</p></div><Radio className="heading-icon"/></div>
        <div className="cards">
          {t.cards.map((card,i)=><motion.article className="story-card" key={card[0]} whileHover={{y:-8}} transition={{duration:.2}}>
            <div className="card-top"><span>0{i+1}</span><span>{['NEWS','ANALYSIS','OPINION'][i]}</span></div>
            <div className={`card-art art-${i}`}><div className="art-ring"></div><b>{['N','A','O'][i]}</b></div>
            <h3>{card[0]}</h3><p>{card[1]}</p><div className="card-foot"><span>AMIROFFICIAL</span><ArrowUpLeft size={18}/></div>
          </motion.article>)}
        </div>
        <p className="preview-note">* {t.note}</p>
      </section>

      <section className="manifesto"><span>03 — MANIFESTO</span><h2>“{t.manifesto}”</h2><div className="manifesto-line"></div></section>

      <section className="contact section" id="contact">
        <div className="section-kicker">04 — CONTACT</div>
        <div className="contact-inner"><div><h2>{t.contact}</h2><p>{t.contactText}</p></div>
          <a className="social" href="https://www.instagram.com/" target="_blank" rel="noreferrer"><Instagram/> Instagram <ArrowUpLeft/></a>
        </div>
      </section>
      <footer><a className="brand" href="#home">AMIR<span>OFFICIAL</span><i>.</i></a><span>{t.footer}</span><a href="mailto:hello@amirofficial.example"><Send size={15}/> Email</a></footer>
    </main>
  );
}
createRoot(document.getElementById('root')).render(<App/>);