# AMIROFFICIAL

Bilingual Persian/English personal media website starter built with React + Vite.

## Run locally

1. Install Node.js (LTS).
2. Open a terminal in this project folder.
3. Run:

   ```bash
   npm install
   npm run dev
   ```

4. Open the local URL printed by Vite.

## Build

```bash
npm run build
```

The production site is generated in `dist/`.

## Before publishing

- Replace the Instagram URL in `src/main.jsx` with your real profile.
- Replace `hello@amirofficial.example` with your real email.
- Replace the sample preview cards with your own verified articles and analysis.
- Update the page title and description in `index.html` if desired.

## GitHub

Upload the extracted project contents to the root of your GitHub repository. Upload the files and folders, not the ZIP archive itself.

For the easiest deployment, import the repository into Vercel and use the default Vite settings.
